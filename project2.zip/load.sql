load data local infile 'user.csv' into table User;
load data local infile 'bid.csv' into table Bid;
load data local infile 'itemcategory.csv' into table ItemCategory;
load data local infile 'item.csv' into table Item;
load data local infile 'bidlocation.csv' into table BidLocation;
load data local infile 'itemlocation.csv' into table ItemLocation;
load data local infile 'location.csv' into table Location;
