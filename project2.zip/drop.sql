drop table if exists User;
drop table if exists Bid;
drop table if exists ItemCategory;
drop table if exists Item;
drop table if exists BidLocation;
drop table if exists ItemLocation;
drop table if exists Location;